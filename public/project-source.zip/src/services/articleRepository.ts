import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { getFirestoreDb, getSavedFirebaseConfig } from './firebase';
import { SEED_ARTICLES, SEED_AUTHORS, SEED_LIVE_STORIES } from '../data/seedData';
import type { Article, Author, LiveStory } from '../types';

const ARTICLES_STORAGE_KEY = 'iamquickagent_articles_v2';
const AUTHORS_STORAGE_KEY = 'iamquickagent_authors_v2';
const LIVE_STORIES_STORAGE_KEY = 'iamquickagent_live_stories_v2';

// Initialize local storage cache if not present
function initializeLocalStorage(): { articles: Article[]; authors: Author[] } {
  let articles = SEED_ARTICLES;
  let authors = SEED_AUTHORS;

  try {
    const cachedArticles = localStorage.getItem(ARTICLES_STORAGE_KEY);
    if (cachedArticles) {
      const parsed = JSON.parse(cachedArticles);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Heal any 2025 dates in cached articles to 2026
        articles = parsed.map((a: Article) => {
          let p = a.publishedAt;
          let u = a.updatedAt;
          if (p && p.startsWith('2025-')) {
            p = p.replace('2025-', '2026-');
          }
          if (u && u.startsWith('2025-')) {
            u = u.replace('2025-', '2026-');
          }
          if (a.headline && a.headline.toLowerCase().includes('japanese fighters')) {
            p = '2026-09-20T09:30:00.000Z';
            u = '2026-09-20T09:30:00.000Z';
          }
          return { ...a, publishedAt: p, updatedAt: u };
        });

        let merged = false;
        for (const seedArt of SEED_ARTICLES) {
          if (!articles.some((a) => a.id === seedArt.id || a.slug === seedArt.slug)) {
            articles = [seedArt, ...articles];
            merged = true;
          }
        }
        localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(articles));
      } else {
        localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(SEED_ARTICLES));
      }
    } else {
      localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(SEED_ARTICLES));
    }

    const cachedAuthors = localStorage.getItem(AUTHORS_STORAGE_KEY);
    if (cachedAuthors) {
      const parsed = JSON.parse(cachedAuthors);
      if (Array.isArray(parsed) && parsed.length > 0) {
        authors = parsed;
        let mergedAuthors = false;
        for (const seedAuth of SEED_AUTHORS) {
          if (!authors.some((a) => a.id === seedAuth.id)) {
            authors = [seedAuth, ...authors];
            mergedAuthors = true;
          }
        }
        if (mergedAuthors) {
          localStorage.setItem(AUTHORS_STORAGE_KEY, JSON.stringify(authors));
        }
      } else {
        localStorage.setItem(AUTHORS_STORAGE_KEY, JSON.stringify(SEED_AUTHORS));
      }
    } else {
      localStorage.setItem(AUTHORS_STORAGE_KEY, JSON.stringify(SEED_AUTHORS));
    }
  } catch (e) {
    console.warn('LocalStorage initialization warning:', e);
  }

  return { articles, authors };
}

export function getLocalArticles(): Article[] {
  try {
    const raw = localStorage.getItem(ARTICLES_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed reading local articles:', e);
  }
  return SEED_ARTICLES;
}

export function setLocalArticles(articles: Article[]): void {
  try {
    localStorage.setItem(ARTICLES_STORAGE_KEY, JSON.stringify(articles));
  } catch (e) {
    console.error('Failed saving local articles:', e);
  }
}

export function getLocalAuthors(): Author[] {
  try {
    const raw = localStorage.getItem(AUTHORS_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed reading local authors:', e);
  }
  return SEED_AUTHORS;
}

export function setLocalAuthors(authors: Author[]): void {
  try {
    localStorage.setItem(AUTHORS_STORAGE_KEY, JSON.stringify(authors));
  } catch (e) {
    console.error('Failed saving local authors:', e);
  }
}

// Ensure seeded on module load
initializeLocalStorage();

/**
 * Fetch all articles with optional filters
 */
export async function getArticles(filter?: {
  category?: string;
  tag?: string;
  search?: string;
  status?: string;
}): Promise<Article[]> {
  const db = getFirestoreDb();
  let list: Article[] = [];

  if (db) {
    try {
      const colRef = collection(db, 'articles');
      const q = query(colRef, orderBy('publishedAt', 'desc'), limit(100));
      const snap = await getDocs(q);
      if (!snap.empty) {
        list = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Article, 'id'>) }));

        // Heal any 2025 dates in Firestore to 2026
        for (const art of list) {
          let needsUpdate = false;
          let newPub = art.publishedAt;
          let newUpd = art.updatedAt;
          if (art.publishedAt && art.publishedAt.startsWith('2025-')) {
            newPub = art.publishedAt.replace('2025-', '2026-');
            needsUpdate = true;
          }
          if (art.updatedAt && art.updatedAt.startsWith('2025-')) {
            newUpd = art.updatedAt.replace('2025-', '2026-');
            needsUpdate = true;
          }
          if (art.headline && art.headline.toLowerCase().includes('japanese fighters') && (!art.publishedAt || art.publishedAt.includes('2025'))) {
            newPub = '2026-09-20T09:30:00.000Z';
            newUpd = '2026-09-20T09:30:00.000Z';
            needsUpdate = true;
          }
          if (needsUpdate) {
            art.publishedAt = newPub;
            art.updatedAt = newUpd;
            try {
              updateDoc(doc(db, 'articles', art.id), {
                publishedAt: newPub,
                updatedAt: newUpd,
              }).catch(() => {});
            } catch {
              // silent
            }
          }
        }

        // Ensure newest seed articles (e.g. newly published articles) exist in Firestore
        for (const seedArt of SEED_ARTICLES) {
          if (!list.some((a) => a.id === seedArt.id || a.slug === seedArt.slug)) {
            try {
              await setDoc(doc(db, 'articles', seedArt.id), seedArt);
              list.unshift(seedArt);
            } catch (err) {
              console.warn('Silent sync seed article:', err);
            }
          }
        }
        setLocalArticles(list); // Keep local backup synced
      } else {
        // If Firestore collection is empty, seed it with initial articles
        for (const art of SEED_ARTICLES) {
          await setDoc(doc(db, 'articles', art.id), art);
        }
        list = SEED_ARTICLES;
        setLocalArticles(list);
      }
    } catch (e) {
      console.warn('Firestore fetch failed, falling back to local storage:', e);
      list = getLocalArticles();
    }
  } else {
    list = getLocalArticles();
  }

  // Filter application
  return list.filter((item) => {
    if (filter?.status && filter.status !== 'all' && item.status !== filter.status) {
      return false;
    }
    if (filter?.category && filter.category !== 'all' && item.category !== filter.category) {
      return false;
    }
    if (filter?.tag && !item.tags.some((t) => t.toLowerCase() === filter.tag?.toLowerCase())) {
      return false;
    }
    if (filter?.search) {
      const s = filter.search.toLowerCase();
      const inHeadline = item.headline.toLowerCase().includes(s);
      const inDeck = item.deck.toLowerCase().includes(s);
      const inContent = item.content.toLowerCase().includes(s);
      const inTakeaways = item.keyTakeaways.some((k) => k.toLowerCase().includes(s));
      const inTags = item.tags.some((t) => t.toLowerCase().includes(s));
      if (!inHeadline && !inDeck && !inContent && !inTakeaways && !inTags) {
        return false;
      }
    }
    return true;
  });
}

/**
 * Get article by slug
 */
export async function getArticleBySlug(slug: string): Promise<Article | null> {
  const all = await getArticles();
  const found = all.find((a) => a.slug === slug);
  return found || null;
}

/**
 * Get breaking news
 */
export async function getBreakingNews(): Promise<Article[]> {
  const all = await getArticles({ status: 'published' });
  return all.filter((a) => a.isBreaking);
}

/**
 * Create article
 */
export async function createArticle(
  data: Omit<Article, 'id' | 'views'>
): Promise<Article> {
  const id = 'art-' + Date.now().toString(36) + '-' + Math.random().toString(36).substring(2, 6);
  const newArticle: Article = {
    ...data,
    id,
    views: 1,
  };

  // 1. Save to LocalStorage immediately
  const current = getLocalArticles();
  const updated = [newArticle, ...current];
  setLocalArticles(updated);

  // 2. Persist to Firestore if available
  const db = getFirestoreDb();
  if (db) {
    try {
      await setDoc(doc(db, 'articles', id), newArticle);
    } catch (e) {
      console.error('Failed saving to Firestore:', e);
    }
  }

  return newArticle;
}

/**
 * Update article
 */
export async function updateArticle(
  id: string,
  updates: Partial<Article>
): Promise<Article | null> {
  const current = getLocalArticles();
  const idx = current.findIndex((a) => a.id === id);
  if (idx === -1) return null;

  const now = new Date().toISOString();
  const updatedArticle: Article = {
    ...current[idx],
    ...updates,
    publishedAt: updates.publishedAt || current[idx].publishedAt || now,
    updatedAt: updates.updatedAt || now,
  };

  current[idx] = updatedArticle;
  setLocalArticles([...current]);

  // Firestore update
  const db = getFirestoreDb();
  if (db) {
    try {
      const docRef = doc(db, 'articles', id);
      await updateDoc(docRef, {
        ...updates,
        publishedAt: updatedArticle.publishedAt,
        updatedAt: updatedArticle.updatedAt,
      });
    } catch (e) {
      console.error('Failed updating Firestore doc:', e);
    }
  }

  return updatedArticle;
}

/**
 * Delete article
 */
export async function deleteArticle(id: string): Promise<boolean> {
  const current = getLocalArticles();
  const filtered = current.filter((a) => a.id !== id);
  setLocalArticles(filtered);

  const db = getFirestoreDb();
  if (db) {
    try {
      await deleteDoc(doc(db, 'articles', id));
    } catch (e) {
      console.error('Failed deleting from Firestore:', e);
    }
  }

  return true;
}

/**
 * Increment view count
 */
export async function incrementArticleViews(id: string): Promise<void> {
  const current = getLocalArticles();
  const idx = current.findIndex((a) => a.id === id);
  if (idx !== -1) {
    current[idx].views = (current[idx].views || 0) + 1;
    setLocalArticles([...current]);

    const db = getFirestoreDb();
    if (db) {
      try {
        await updateDoc(doc(db, 'articles', id), {
          views: current[idx].views,
        });
      } catch (e) {
        // Silent view increment error
      }
    }
  }
}

/**
 * Get all authors
 */
export async function getAuthors(): Promise<Author[]> {
  const db = getFirestoreDb();
  if (db) {
    try {
      const snap = await getDocs(collection(db, 'authors'));
      if (!snap.empty) {
        let authors = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Author, 'id'>) }));
        for (const seedAuth of SEED_AUTHORS) {
          if (!authors.some((a) => a.id === seedAuth.id)) {
            try {
              await setDoc(doc(db, 'authors', seedAuth.id), seedAuth);
              authors.unshift(seedAuth);
            } catch (err) {
              console.warn('Silent sync seed author:', err);
            }
          }
        }
        setLocalAuthors(authors);
        return authors;
      } else {
        for (const auth of SEED_AUTHORS) {
          await setDoc(doc(db, 'authors', auth.id), auth);
        }
      }
    } catch (e) {
      console.warn('Firestore authors fetch failed, using local storage:', e);
    }
  }
  return getLocalAuthors();
}

/**
 * Get author by id
 */
export async function getAuthorById(id: string): Promise<Author | null> {
  const authors = await getAuthors();
  return authors.find((a) => a.id === id) || null;
}

/**
 * Create author
 */
export async function createAuthor(data: Omit<Author, 'id'>): Promise<Author> {
  const id = 'author-' + data.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
  const newAuthor: Author = { ...data, id };

  const current = getLocalAuthors();
  setLocalAuthors([...current, newAuthor]);

  const db = getFirestoreDb();
  if (db) {
    try {
      await setDoc(doc(db, 'authors', id), newAuthor);
    } catch (e) {
      console.error('Failed saving author to Firestore:', e);
    }
  }

  return newAuthor;
}

/**
 * Check connectivity status for UI indicator
 */
export function getStorageStatus(): {
  isCloud: boolean;
  provider: 'Firestore' | 'Local Persistent Storage';
  details: string;
} {
  const config = getSavedFirebaseConfig();
  if (config && config.projectId) {
    return {
      isCloud: true,
      provider: 'Firestore',
      details: `Connected to Firebase Project [${config.projectId}]`,
    };
  }
  return {
    isCloud: false,
    provider: 'Local Persistent Storage',
    details: 'Operating on Local IndexedDB/Storage. Add Firebase credentials to enable cross-device cloud sync.',
  };
}

/**
 * Local storage helpers for Live Stories
 */
const BROKEN_IMAGE_HEALING_MAP: Record<string, string> = {
  'photo-1601055903647-87332213e2d6': 'https://images.unsplash.com/photo-1620766182966-c6eb5ed2b788?auto=format&fit=crop&w=300&q=80',
  'photo-1517976487502-5f7140e4f3a9': 'https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?auto=format&fit=crop&w=300&q=80',
  'photo-1531415074868-036b1c57e329': 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=300&q=80',
};

export function getLocalLiveStories(): LiveStory[] {
  try {
    const raw = localStorage.getItem(LIVE_STORIES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        let merged = false;
        // Fix any legacy 404 URLs in cached local storage
        for (const story of parsed as LiveStory[]) {
          if (story.id === 'story-brics-2026') {
            if (!story.image || story.image.includes('photo-1517976487502-5f7140e4f3a9')) {
              story.image = '/brics-2026-summit.svg';
              merged = true;
            }
          }
          for (const [badKey, goodUrl] of Object.entries(BROKEN_IMAGE_HEALING_MAP)) {
            if (story.image && story.image.includes(badKey)) {
              story.image = goodUrl;
              merged = true;
            }
          }
        }
        for (const seedStory of SEED_LIVE_STORIES) {
          if (!parsed.some((s: LiveStory) => s.id === seedStory.id)) {
            parsed.unshift(seedStory);
            merged = true;
          }
        }
        if (merged) {
          localStorage.setItem(LIVE_STORIES_STORAGE_KEY, JSON.stringify(parsed));
        }
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed reading local live stories:', e);
  }
  return SEED_LIVE_STORIES;
}

export function setLocalLiveStories(stories: LiveStory[]): void {
  try {
    localStorage.setItem(LIVE_STORIES_STORAGE_KEY, JSON.stringify(stories));
  } catch (e) {
    console.error('Failed saving local live stories:', e);
  }
}

/**
 * Get all live stories from Firestore or Local Cache
 */
export async function getLiveStories(): Promise<LiveStory[]> {
  const db = getFirestoreDb();
  if (db) {
    try {
      const snap = await getDocs(collection(db, 'live_stories'));
      if (!snap.empty) {
        let stories = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<LiveStory, 'id'>),
        }));

        // Heal any legacy 404 image URLs in Firestore
        for (const story of stories) {
          if (story.id === 'story-brics-2026') {
            if (!story.image || story.image.includes('photo-1517976487502-5f7140e4f3a9')) {
              story.image = '/brics-2026-summit.svg';
              updateDoc(doc(db, 'live_stories', story.id), { image: '/brics-2026-summit.svg' }).catch(console.warn);
            }
          }
          for (const [badKey, goodUrl] of Object.entries(BROKEN_IMAGE_HEALING_MAP)) {
            if (story.image && story.image.includes(badKey)) {
              story.image = goodUrl;
              updateDoc(doc(db, 'live_stories', story.id), { image: goodUrl }).catch(console.warn);
            }
          }
        }

        // Merge any missing seed stories into Firestore
        for (const seedStory of SEED_LIVE_STORIES) {
          if (!stories.some((s) => s.id === seedStory.id)) {
            stories.unshift(seedStory);
            setDoc(doc(db, 'live_stories', seedStory.id), seedStory).catch(console.warn);
          }
        }

        setLocalLiveStories(stories);
        return stories;
      } else {
        // Seed Firestore with initial live stories
        for (const story of SEED_LIVE_STORIES) {
          await setDoc(doc(db, 'live_stories', story.id), story);
        }
      }
    } catch (e) {
      console.warn('Firestore live stories fetch failed, falling back to local storage:', e);
    }
  }
  return getLocalLiveStories();
}

/**
 * Create a new live story
 */
export async function createLiveStory(data: Omit<LiveStory, 'id'>): Promise<LiveStory> {
  const id = 'story-' + Date.now();
  const newStory: LiveStory = { ...data, id };

  const current = getLocalLiveStories();
  setLocalLiveStories([newStory, ...current]);

  const db = getFirestoreDb();
  if (db) {
    try {
      await setDoc(doc(db, 'live_stories', id), newStory);
    } catch (e) {
      console.error('Failed saving live story to Firestore:', e);
    }
  }

  return newStory;
}

/**
 * Update an existing live story
 */
export async function updateLiveStory(
  id: string,
  updates: Partial<LiveStory>
): Promise<LiveStory | null> {
  const current = getLocalLiveStories();
  const idx = current.findIndex((s) => s.id === id);
  if (idx === -1) return null;

  const updatedStory = { ...current[idx], ...updates, id };
  current[idx] = updatedStory;
  setLocalLiveStories([...current]);

  const db = getFirestoreDb();
  if (db) {
    try {
      await updateDoc(doc(db, 'live_stories', id), updates);
    } catch (e) {
      console.error('Failed updating live story in Firestore:', e);
    }
  }

  return updatedStory;
}

/**
 * Delete a live story
 */
export async function deleteLiveStory(id: string): Promise<boolean> {
  const current = getLocalLiveStories();
  const filtered = current.filter((s) => s.id !== id);
  setLocalLiveStories(filtered);

  const db = getFirestoreDb();
  if (db) {
    try {
      await deleteDoc(doc(db, 'live_stories', id));
    } catch (e) {
      console.error('Failed deleting live story from Firestore:', e);
    }
  }

  return true;
}

/**
 * Toggle the LIVE status of a story
 */
export async function toggleLiveStoryStatus(id: string): Promise<boolean> {
  const current = getLocalLiveStories();
  const story = current.find((s) => s.id === id);
  if (!story) return false;

  const newIsLive = !story.isLive;
  await updateLiveStory(id, { isLive: newIsLive });
  return newIsLive;
}
